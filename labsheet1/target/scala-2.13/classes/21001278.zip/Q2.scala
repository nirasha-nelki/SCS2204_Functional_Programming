object Q2{
  def convert(c:Double):Double = c*1.80000+32.00

  def main(args: Array[String])= {
    println(convert(35))
  }
}
