object Q1 {
  var pi : Double = 22 / 7

  def cal(r: Int): Double = pi * r * r

  def main(args: Array[String]) = {
    println(cal(5))
  }
}
