object Q3 {
  var pi : Float = 22/7
  def cal(r:Int):Float= (4/3)*pi*r*r*r

  def main(args: Array[String])= {
    println(cal(5))
  }
}
