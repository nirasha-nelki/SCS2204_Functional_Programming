object Q4 {
  var bestPrice : Int = 0
  var bestProfit : Int = 0

  def attendees(price: Int) = 120 - 4 * (price-15)

  def attenanceCost(price: Int) = attendees(price)*3

  def totCost(price:Int) : Int = 500 + attenanceCost(attendees(price))

  def income(price:Int): Int = price*attendees(price)

  def calProfit(price: Int) : Int = income(price) - totCost(price)

  def calBestPrice() : Int = {
    for (i <- 5 until (40, 5)){
      var profit : Int = calProfit(i)

      if (profit >= bestProfit){
        bestProfit = profit
        bestPrice = i
      }
    }
    bestPrice
  }

  def main(args: Array[String]): Unit = {
    println("the best ticket price is " + calBestPrice())
  }
}

